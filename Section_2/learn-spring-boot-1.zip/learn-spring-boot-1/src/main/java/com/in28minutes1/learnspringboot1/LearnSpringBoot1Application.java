package com.in28minutes1.learnspringboot1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnSpringBoot1Application {

	public static void main(String[] args) {
		SpringApplication.run(LearnSpringBoot1Application.class, args);
	}

}
