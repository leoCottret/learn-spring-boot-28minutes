package com.in28minutes1.learnspringboot1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnSpringBoot1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
